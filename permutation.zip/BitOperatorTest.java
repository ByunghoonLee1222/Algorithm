package com.ssafy.step1.permutation;

public class BitOperatorTest {

	public static void main(String[] args) {
		int i =1,j=6;
		System.out.println("i: "+Integer.toBinaryString(i));
		System.out.println("j: "+Integer.toBinaryString(j));
		System.out.println("i<<2 :"+Integer.toBinaryString(i<<2));
		//	  j  110   의 첫번째 1이 켜져있는지 꺼져있는지 궁금할때 &	
		// 1<<0: 001	궁금한 자리가 0이면 꺼짐 1이면 켜짐
		// 1<<1: 010
		// 1<<2: 100  
		System.out.println("j&(1<<2) :"+Integer.toBinaryString(j&(1<<2)));
		System.out.println("j&(1<<1) :"+Integer.toBinaryString(j&(1<<1)));
		System.out.println("j&(1<<1) :"+Integer.toBinaryString(j&(1<<0)));
		//	  j  110   원하는 비트열을 켜기위해 |
		// 1<<0: 001	
		// 1<<1: 010
		// 1<<2: 100  
		System.out.println("j&(1<<2) :"+Integer.toBinaryString(j|(1<<2)));
		System.out.println("j&(1<<1) :"+Integer.toBinaryString(j|(1<<1)));
		System.out.println("j&(1<<1) :"+Integer.toBinaryString(j|(1<<0)));
	}

}
