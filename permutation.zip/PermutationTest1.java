package com.ssafy.step1.permutation;

public class PermutationTest1 {

	//1,2,3 세 수중 3자리 순열
	//3P3
	public static void main(String[] args) {
		//개수가 고정되어있을때 사용가능  //4개의 수는 반목문 하나 추가해야 함
		for(int i =1;i<=3;++i){//첫번째 수 
			//0번째 수랑 같은지 비교
			for(int j=1;j<=3;++j){//두번째 수
				if(i==j)continue; //1번째 수랑 같은지 비교
				for(int k=1;k<=3;++k){//세번째 수
					if(i!=k && j!=k) {
						System.out.println(i+" "+j+" "+k);
					}//if end
				}//k end
			}//j end
		}//i end
		//k end
	}	

}
