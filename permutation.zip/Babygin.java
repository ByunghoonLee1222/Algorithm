package com.ssafy.step1.permutation;

import java.util.Arrays;
import java.util.Scanner;

public class Babygin {
	
	static int[][] permutationList;
	static int p;// 인덱스 순열리스트의 index
	static int N = 6;
	static int[] numbers, temp;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int size =1;
		for(int i=1; i<N;++i) {
			size *=i;
		}
		permutationList = new int[size][N];
		temp = new int[N];
		permutation(0, 0);
		
		int T = sc.nextInt();
		numbers = new int[N];
		for(int t =1; t<=T;++t) {
			char[] data = sc.next().toCharArray();
			for(int i=0; i<N;++i) {
				numbers[i] = data[i]-'0';
			}
			boolean check =false;
			for(int i=0; i<size;++i) {
				if(check=babygin(i))break;
			}
		}
	}

	private static void permutation(int count, int flag) {
		if (count == N) {
			permutationList[p++] = Arrays.copyOf(temp, N);
			System.out.println(Arrays.toString(permutationList[p - 1]));
			return;
		}

		for (int i = 0; i < N; ++i) {
			if ((flag & 1 << i) == 0) {
				temp[count] = i;
				permutation(count + 1, flag | 1 << i);
			}
		}
	}

	public static boolean babygin(int index) {
		boolean isbg = false;
		if(numbers[0]==numbers[1] && numbers[1]==numbers[2]) {
			isbg = true;
		}else if(numbers[0]==(numbers[1]-1) && numbers[1]==(numbers[2]-1)) {
			isbg = true;
		}
		if(numbers[3]==numbers[4] && numbers[4]==numbers[5]) {
			isbg = true;
		}else if(numbers[0]==(numbers[1]-1) && numbers[1]==(numbers[2]-1)) {
			isbg = true;
		}
		return isbg;
		
	}

}
